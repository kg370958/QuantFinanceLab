```python
import pandas as pd
import numpy as np
import random as random
import matplotlib.pyplot as plt
import seaborn as sns
import yfinance as yf  

import cvxpy as cp

```


```python
tickers = [
   
    "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "HINDUNILVR.NS",
    "ICICIBANK.NS", "BHARTIARTL.NS", "ITC.NS", "KOTAKBANK.NS", "LT.NS",
    "GODREJCP.NS", "FEDERALBNK.NS", "TATAPOWER.NS", "APOLLOHOSP.NS", "ASHOKLEY.NS",
    "MUTHOOTFIN.NS", "JUBLFOOD.NS", "BIOCON.NS", "MINDTREE.NS", "CROMPTON.NS",
    "VMART.NS", "KEC.NS", "BAJAJELEC.NS", "CHALET.NS", "DIXON.NS",
    "ELGIEQUIP.NS", "FSL.NS", "GRANULES.NS", "HIMATSEIDE.NS", "IDFC.NS",
    "L&TFH.NS", "MANAPPURAM.NS", "NBCC.NS", "OBEROIRLTY.NS", "PVR.NS",
    "RAYMOND.NS", "SUNTECK.NS", "TV18BRDCST.NS", "UNIONBANK.NS", "VBL.NS",
    "WELSPUNIND.NS", "YESBANK.NS", "ZEEL.NS", "AJANTPHARM.NS", "BLUESTARCO.NS",
    "CENTURYPLY.NS", "DALMIASUG.NS", "EMAMILTD.NS", "FINCABLES.NS", "GMDCLTD.NS",
    "HCC.NS", "ITDCEM.NS", "JSL.NS", "KSCL.NS", "LUXIND.NS"
]



# Define the start and end date for the 3-year period
end_date = pd.Timestamp.now()
start_date = end_date - pd.DateOffset(years=3)

# Initialize a DataFrame to hold the return data
monthly_returns = pd.DataFrame()

# Fetch the data for each stock
for ticker in tickers:
    stock = yf.Ticker(ticker)
    
    # Fetch historical market data
    hist = stock.history(start=start_date, end=end_date, interval='1mo')
    
    
    if not hist.empty:  # Check if the DataFrame is not empty 
        
        # Calculate monthly returns
        
        
        monthly_ret = hist['Open'].pct_change().dropna()
        
        # Add to the DataFrame
        monthly_returns[ticker] = monthly_ret
    else:
        print(f"No data returned for {ticker}")
    
    # Add to the DataFrame
   


monthly_returns.index = pd.to_datetime(monthly_returns.index)
```

    MINDTREE.NS: No timezone found, symbol may be delisted
    

    No data returned for MINDTREE.NS
    

    PVR.NS: No timezone found, symbol may be delisted
    

    No data returned for PVR.NS
    

    WELSPUNIND.NS: No timezone found, symbol may be delisted
    

    No data returned for WELSPUNIND.NS
    


```python
monthly_returns.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RELIANCE.NS</th>
      <th>TCS.NS</th>
      <th>HDFCBANK.NS</th>
      <th>INFY.NS</th>
      <th>HINDUNILVR.NS</th>
      <th>ICICIBANK.NS</th>
      <th>BHARTIARTL.NS</th>
      <th>ITC.NS</th>
      <th>KOTAKBANK.NS</th>
      <th>LT.NS</th>
      <th>...</th>
      <th>CENTURYPLY.NS</th>
      <th>DALMIASUG.NS</th>
      <th>EMAMILTD.NS</th>
      <th>FINCABLES.NS</th>
      <th>GMDCLTD.NS</th>
      <th>HCC.NS</th>
      <th>ITDCEM.NS</th>
      <th>JSL.NS</th>
      <th>KSCL.NS</th>
      <th>LUXIND.NS</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2021-05-01 00:00:00+05:30</th>
      <td>-0.025768</td>
      <td>-0.052083</td>
      <td>-0.070962</td>
      <td>-0.028406</td>
      <td>-0.042423</td>
      <td>0.008510</td>
      <td>0.019329</td>
      <td>-0.085455</td>
      <td>-0.019774</td>
      <td>-0.074371</td>
      <td>...</td>
      <td>0.092857</td>
      <td>0.334745</td>
      <td>0.017220</td>
      <td>-0.046002</td>
      <td>0.097297</td>
      <td>-0.089286</td>
      <td>-0.106383</td>
      <td>0.316214</td>
      <td>0.161390</td>
      <td>0.089760</td>
    </tr>
    <tr>
      <th>2021-06-01 00:00:00+05:30</th>
      <td>0.101729</td>
      <td>0.052630</td>
      <td>0.091386</td>
      <td>0.055420</td>
      <td>0.001707</td>
      <td>0.121509</td>
      <td>0.014057</td>
      <td>0.083499</td>
      <td>0.046109</td>
      <td>0.105960</td>
      <td>...</td>
      <td>0.136687</td>
      <td>0.296590</td>
      <td>0.025699</td>
      <td>0.214452</td>
      <td>0.212644</td>
      <td>0.424837</td>
      <td>0.182073</td>
      <td>0.040691</td>
      <td>0.201380</td>
      <td>0.644837</td>
    </tr>
    <tr>
      <th>2021-07-01 00:00:00+05:30</th>
      <td>-0.018752</td>
      <td>0.059774</td>
      <td>-0.007761</td>
      <td>0.126321</td>
      <td>0.066030</td>
      <td>-0.046046</td>
      <td>-0.015722</td>
      <td>-0.043381</td>
      <td>-0.057906</td>
      <td>0.021249</td>
      <td>...</td>
      <td>0.037375</td>
      <td>0.437309</td>
      <td>0.118612</td>
      <td>0.199095</td>
      <td>-0.075152</td>
      <td>0.288991</td>
      <td>-0.023104</td>
      <td>0.177825</td>
      <td>0.010169</td>
      <td>0.145280</td>
    </tr>
    <tr>
      <th>2021-08-01 00:00:00+05:30</th>
      <td>-0.030075</td>
      <td>-0.050941</td>
      <td>-0.044607</td>
      <td>0.032089</td>
      <td>-0.057166</td>
      <td>0.082188</td>
      <td>0.069943</td>
      <td>0.017496</td>
      <td>-0.026259</td>
      <td>0.085086</td>
      <td>...</td>
      <td>0.032052</td>
      <td>0.053191</td>
      <td>0.004355</td>
      <td>-0.015094</td>
      <td>0.027818</td>
      <td>-0.153025</td>
      <td>0.049121</td>
      <td>0.492042</td>
      <td>-0.006848</td>
      <td>0.159832</td>
    </tr>
    <tr>
      <th>2021-09-01 00:00:00+05:30</th>
      <td>0.106460</td>
      <td>0.193711</td>
      <td>0.097561</td>
      <td>0.050416</td>
      <td>0.172075</td>
      <td>0.063665</td>
      <td>0.180212</td>
      <td>0.022039</td>
      <td>0.053826</td>
      <td>0.041057</td>
      <td>...</td>
      <td>-0.040100</td>
      <td>-0.121212</td>
      <td>0.058761</td>
      <td>-0.109387</td>
      <td>-0.000712</td>
      <td>-0.155462</td>
      <td>-0.090751</td>
      <td>-0.080463</td>
      <td>-0.205627</td>
      <td>-0.040545</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 52 columns</p>
</div>




```python
monthly_returns.cov()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RELIANCE.NS</th>
      <th>TCS.NS</th>
      <th>HDFCBANK.NS</th>
      <th>INFY.NS</th>
      <th>HINDUNILVR.NS</th>
      <th>ICICIBANK.NS</th>
      <th>BHARTIARTL.NS</th>
      <th>ITC.NS</th>
      <th>KOTAKBANK.NS</th>
      <th>LT.NS</th>
      <th>...</th>
      <th>CENTURYPLY.NS</th>
      <th>DALMIASUG.NS</th>
      <th>EMAMILTD.NS</th>
      <th>FINCABLES.NS</th>
      <th>GMDCLTD.NS</th>
      <th>HCC.NS</th>
      <th>ITDCEM.NS</th>
      <th>JSL.NS</th>
      <th>KSCL.NS</th>
      <th>LUXIND.NS</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>RELIANCE.NS</th>
      <td>0.003244</td>
      <td>0.001584</td>
      <td>0.001095</td>
      <td>0.000960</td>
      <td>0.000089</td>
      <td>0.001341</td>
      <td>0.001708</td>
      <td>0.001071</td>
      <td>0.001451</td>
      <td>0.000750</td>
      <td>...</td>
      <td>0.001609</td>
      <td>0.000431</td>
      <td>-0.000054</td>
      <td>0.000872</td>
      <td>0.002376</td>
      <td>0.000919</td>
      <td>0.001187</td>
      <td>-0.000372</td>
      <td>0.001434</td>
      <td>0.001533</td>
    </tr>
    <tr>
      <th>TCS.NS</th>
      <td>0.001584</td>
      <td>0.003338</td>
      <td>0.001636</td>
      <td>0.002340</td>
      <td>0.001558</td>
      <td>0.000459</td>
      <td>0.001235</td>
      <td>0.000508</td>
      <td>0.000410</td>
      <td>0.001344</td>
      <td>...</td>
      <td>0.000175</td>
      <td>0.000982</td>
      <td>0.000819</td>
      <td>0.000569</td>
      <td>0.001265</td>
      <td>0.001659</td>
      <td>-0.000111</td>
      <td>0.000036</td>
      <td>0.000529</td>
      <td>0.000912</td>
    </tr>
    <tr>
      <th>HDFCBANK.NS</th>
      <td>0.001095</td>
      <td>0.001636</td>
      <td>0.003103</td>
      <td>0.000970</td>
      <td>0.001457</td>
      <td>0.001384</td>
      <td>0.000602</td>
      <td>0.001539</td>
      <td>0.001686</td>
      <td>0.002075</td>
      <td>...</td>
      <td>0.001577</td>
      <td>0.000858</td>
      <td>0.000678</td>
      <td>0.001286</td>
      <td>0.001204</td>
      <td>-0.000995</td>
      <td>0.001032</td>
      <td>0.000605</td>
      <td>0.000286</td>
      <td>0.001541</td>
    </tr>
    <tr>
      <th>INFY.NS</th>
      <td>0.000960</td>
      <td>0.002340</td>
      <td>0.000970</td>
      <td>0.004568</td>
      <td>0.000603</td>
      <td>0.000830</td>
      <td>0.000766</td>
      <td>-0.000152</td>
      <td>-0.000511</td>
      <td>0.001355</td>
      <td>...</td>
      <td>0.001654</td>
      <td>0.002319</td>
      <td>0.000497</td>
      <td>0.000799</td>
      <td>0.001665</td>
      <td>0.005840</td>
      <td>0.001510</td>
      <td>0.003163</td>
      <td>0.001524</td>
      <td>0.001753</td>
    </tr>
    <tr>
      <th>HINDUNILVR.NS</th>
      <td>0.000089</td>
      <td>0.001558</td>
      <td>0.001457</td>
      <td>0.000603</td>
      <td>0.004153</td>
      <td>0.000717</td>
      <td>0.000418</td>
      <td>0.000821</td>
      <td>0.001134</td>
      <td>0.000843</td>
      <td>...</td>
      <td>-0.000617</td>
      <td>0.000476</td>
      <td>0.001948</td>
      <td>0.000281</td>
      <td>-0.001673</td>
      <td>0.000011</td>
      <td>0.001636</td>
      <td>-0.001881</td>
      <td>-0.001548</td>
      <td>0.000842</td>
    </tr>
    <tr>
      <th>ICICIBANK.NS</th>
      <td>0.001341</td>
      <td>0.000459</td>
      <td>0.001384</td>
      <td>0.000830</td>
      <td>0.000717</td>
      <td>0.004085</td>
      <td>0.000756</td>
      <td>0.000659</td>
      <td>0.001857</td>
      <td>0.002161</td>
      <td>...</td>
      <td>0.000905</td>
      <td>0.001345</td>
      <td>0.000288</td>
      <td>0.000915</td>
      <td>0.002367</td>
      <td>0.000121</td>
      <td>0.003664</td>
      <td>0.002885</td>
      <td>0.000868</td>
      <td>0.003122</td>
    </tr>
    <tr>
      <th>BHARTIARTL.NS</th>
      <td>0.001708</td>
      <td>0.001235</td>
      <td>0.000602</td>
      <td>0.000766</td>
      <td>0.000418</td>
      <td>0.000756</td>
      <td>0.003738</td>
      <td>0.000664</td>
      <td>0.000880</td>
      <td>0.000572</td>
      <td>...</td>
      <td>0.001519</td>
      <td>0.000759</td>
      <td>0.000066</td>
      <td>0.000362</td>
      <td>0.002256</td>
      <td>-0.000385</td>
      <td>0.001902</td>
      <td>-0.000542</td>
      <td>-0.000157</td>
      <td>0.000551</td>
    </tr>
    <tr>
      <th>ITC.NS</th>
      <td>0.001071</td>
      <td>0.000508</td>
      <td>0.001539</td>
      <td>-0.000152</td>
      <td>0.000821</td>
      <td>0.000659</td>
      <td>0.000664</td>
      <td>0.003188</td>
      <td>0.001744</td>
      <td>0.000904</td>
      <td>...</td>
      <td>0.001827</td>
      <td>-0.000768</td>
      <td>-0.000158</td>
      <td>0.001708</td>
      <td>0.001458</td>
      <td>-0.002880</td>
      <td>0.001026</td>
      <td>-0.002603</td>
      <td>0.000702</td>
      <td>0.000530</td>
    </tr>
    <tr>
      <th>KOTAKBANK.NS</th>
      <td>0.001451</td>
      <td>0.000410</td>
      <td>0.001686</td>
      <td>-0.000511</td>
      <td>0.001134</td>
      <td>0.001857</td>
      <td>0.000880</td>
      <td>0.001744</td>
      <td>0.003385</td>
      <td>0.001413</td>
      <td>...</td>
      <td>0.001645</td>
      <td>-0.000208</td>
      <td>0.000397</td>
      <td>0.001350</td>
      <td>0.002000</td>
      <td>-0.002323</td>
      <td>0.001331</td>
      <td>-0.001227</td>
      <td>0.000358</td>
      <td>0.001117</td>
    </tr>
    <tr>
      <th>LT.NS</th>
      <td>0.000750</td>
      <td>0.001344</td>
      <td>0.002075</td>
      <td>0.001355</td>
      <td>0.000843</td>
      <td>0.002161</td>
      <td>0.000572</td>
      <td>0.000904</td>
      <td>0.001413</td>
      <td>0.003798</td>
      <td>...</td>
      <td>0.001930</td>
      <td>0.001907</td>
      <td>0.001371</td>
      <td>0.002957</td>
      <td>0.001959</td>
      <td>0.001799</td>
      <td>0.002540</td>
      <td>0.003399</td>
      <td>0.001453</td>
      <td>0.003104</td>
    </tr>
    <tr>
      <th>GODREJCP.NS</th>
      <td>0.000896</td>
      <td>0.001682</td>
      <td>0.001212</td>
      <td>0.001637</td>
      <td>0.002887</td>
      <td>0.002079</td>
      <td>0.000801</td>
      <td>0.000812</td>
      <td>0.000410</td>
      <td>0.001518</td>
      <td>...</td>
      <td>0.000755</td>
      <td>0.001401</td>
      <td>0.001507</td>
      <td>0.001216</td>
      <td>-0.001779</td>
      <td>0.003481</td>
      <td>0.004149</td>
      <td>0.001935</td>
      <td>0.000517</td>
      <td>0.006337</td>
    </tr>
    <tr>
      <th>FEDERALBNK.NS</th>
      <td>0.000343</td>
      <td>-0.000658</td>
      <td>0.001373</td>
      <td>0.000015</td>
      <td>-0.000581</td>
      <td>0.002775</td>
      <td>-0.000002</td>
      <td>0.000311</td>
      <td>0.001469</td>
      <td>0.002146</td>
      <td>...</td>
      <td>0.001666</td>
      <td>0.003409</td>
      <td>0.000797</td>
      <td>0.001557</td>
      <td>0.005011</td>
      <td>-0.000710</td>
      <td>0.003425</td>
      <td>0.004802</td>
      <td>0.000271</td>
      <td>0.000893</td>
    </tr>
    <tr>
      <th>TATAPOWER.NS</th>
      <td>0.002812</td>
      <td>0.001041</td>
      <td>0.001384</td>
      <td>0.002429</td>
      <td>-0.000296</td>
      <td>0.003255</td>
      <td>0.001861</td>
      <td>0.000659</td>
      <td>0.002739</td>
      <td>0.002769</td>
      <td>...</td>
      <td>0.005775</td>
      <td>0.002510</td>
      <td>0.001183</td>
      <td>0.002524</td>
      <td>0.004100</td>
      <td>0.004076</td>
      <td>0.003684</td>
      <td>0.003395</td>
      <td>0.001484</td>
      <td>0.002251</td>
    </tr>
    <tr>
      <th>APOLLOHOSP.NS</th>
      <td>0.000391</td>
      <td>0.001825</td>
      <td>0.000247</td>
      <td>0.001872</td>
      <td>0.001696</td>
      <td>-0.000051</td>
      <td>0.002906</td>
      <td>-0.000664</td>
      <td>0.000288</td>
      <td>0.001086</td>
      <td>...</td>
      <td>0.002215</td>
      <td>0.002032</td>
      <td>0.002180</td>
      <td>0.003841</td>
      <td>-0.003164</td>
      <td>0.000273</td>
      <td>0.000772</td>
      <td>0.000912</td>
      <td>-0.001596</td>
      <td>0.004472</td>
    </tr>
    <tr>
      <th>ASHOKLEY.NS</th>
      <td>0.000782</td>
      <td>-0.000666</td>
      <td>0.001009</td>
      <td>-0.000324</td>
      <td>-0.000049</td>
      <td>0.001703</td>
      <td>-0.000152</td>
      <td>0.001187</td>
      <td>0.000719</td>
      <td>0.001486</td>
      <td>...</td>
      <td>0.001182</td>
      <td>0.000647</td>
      <td>0.000800</td>
      <td>0.001573</td>
      <td>0.000949</td>
      <td>0.000688</td>
      <td>0.004060</td>
      <td>0.001394</td>
      <td>0.001617</td>
      <td>0.002511</td>
    </tr>
    <tr>
      <th>MUTHOOTFIN.NS</th>
      <td>0.000782</td>
      <td>0.001035</td>
      <td>0.001635</td>
      <td>0.001912</td>
      <td>0.001344</td>
      <td>0.001754</td>
      <td>0.000878</td>
      <td>0.000540</td>
      <td>0.000923</td>
      <td>0.002410</td>
      <td>...</td>
      <td>0.002380</td>
      <td>0.005392</td>
      <td>0.001821</td>
      <td>0.002757</td>
      <td>0.002170</td>
      <td>0.004707</td>
      <td>0.004854</td>
      <td>0.004296</td>
      <td>0.002060</td>
      <td>0.006313</td>
    </tr>
    <tr>
      <th>JUBLFOOD.NS</th>
      <td>-0.000099</td>
      <td>0.000377</td>
      <td>0.001053</td>
      <td>0.000531</td>
      <td>0.002078</td>
      <td>0.001512</td>
      <td>0.001729</td>
      <td>0.001021</td>
      <td>0.001292</td>
      <td>0.002112</td>
      <td>...</td>
      <td>0.001800</td>
      <td>0.001187</td>
      <td>0.002469</td>
      <td>0.001817</td>
      <td>0.000493</td>
      <td>0.000369</td>
      <td>0.006108</td>
      <td>0.002020</td>
      <td>-0.000274</td>
      <td>0.004790</td>
    </tr>
    <tr>
      <th>BIOCON.NS</th>
      <td>0.001259</td>
      <td>0.000914</td>
      <td>0.000317</td>
      <td>0.000403</td>
      <td>0.000364</td>
      <td>0.000675</td>
      <td>0.001174</td>
      <td>0.000270</td>
      <td>0.000592</td>
      <td>0.001102</td>
      <td>...</td>
      <td>0.001848</td>
      <td>0.002078</td>
      <td>0.001723</td>
      <td>0.002457</td>
      <td>0.002143</td>
      <td>0.005916</td>
      <td>0.003940</td>
      <td>0.000508</td>
      <td>0.000890</td>
      <td>0.003000</td>
    </tr>
    <tr>
      <th>CROMPTON.NS</th>
      <td>-0.000236</td>
      <td>0.000204</td>
      <td>0.000294</td>
      <td>0.001199</td>
      <td>0.002041</td>
      <td>0.001393</td>
      <td>0.000245</td>
      <td>-0.000090</td>
      <td>0.000475</td>
      <td>0.001654</td>
      <td>...</td>
      <td>0.001747</td>
      <td>0.002170</td>
      <td>0.003287</td>
      <td>0.001596</td>
      <td>-0.000438</td>
      <td>0.001252</td>
      <td>0.002988</td>
      <td>0.003844</td>
      <td>-0.001004</td>
      <td>0.003467</td>
    </tr>
    <tr>
      <th>VMART.NS</th>
      <td>0.001523</td>
      <td>0.000156</td>
      <td>0.001708</td>
      <td>0.003042</td>
      <td>-0.000966</td>
      <td>0.003617</td>
      <td>0.002251</td>
      <td>0.001356</td>
      <td>0.001533</td>
      <td>0.003645</td>
      <td>...</td>
      <td>0.006404</td>
      <td>0.003352</td>
      <td>0.000438</td>
      <td>0.001580</td>
      <td>0.003707</td>
      <td>0.002339</td>
      <td>0.003395</td>
      <td>0.009188</td>
      <td>0.002874</td>
      <td>0.004394</td>
    </tr>
    <tr>
      <th>KEC.NS</th>
      <td>-0.000448</td>
      <td>-0.000177</td>
      <td>-0.000652</td>
      <td>0.000181</td>
      <td>0.001198</td>
      <td>0.001641</td>
      <td>-0.001372</td>
      <td>-0.001107</td>
      <td>-0.000059</td>
      <td>0.000778</td>
      <td>...</td>
      <td>-0.001364</td>
      <td>0.000867</td>
      <td>0.000912</td>
      <td>0.000808</td>
      <td>-0.002152</td>
      <td>0.005901</td>
      <td>0.002669</td>
      <td>0.002851</td>
      <td>-0.000290</td>
      <td>0.001678</td>
    </tr>
    <tr>
      <th>BAJAJELEC.NS</th>
      <td>-0.000106</td>
      <td>0.000052</td>
      <td>-0.000320</td>
      <td>0.000036</td>
      <td>0.000905</td>
      <td>0.000389</td>
      <td>0.000471</td>
      <td>-0.000171</td>
      <td>-0.000293</td>
      <td>0.000826</td>
      <td>...</td>
      <td>0.001038</td>
      <td>0.001764</td>
      <td>0.000730</td>
      <td>-0.000090</td>
      <td>-0.000782</td>
      <td>0.002666</td>
      <td>0.001689</td>
      <td>0.005102</td>
      <td>0.001068</td>
      <td>0.001223</td>
    </tr>
    <tr>
      <th>CHALET.NS</th>
      <td>0.002810</td>
      <td>0.000605</td>
      <td>0.000682</td>
      <td>0.000637</td>
      <td>-0.000984</td>
      <td>0.000450</td>
      <td>0.001432</td>
      <td>0.002400</td>
      <td>0.002326</td>
      <td>0.000250</td>
      <td>...</td>
      <td>0.003512</td>
      <td>0.000372</td>
      <td>0.000436</td>
      <td>0.001860</td>
      <td>0.005642</td>
      <td>0.001063</td>
      <td>0.002141</td>
      <td>-0.001184</td>
      <td>0.001520</td>
      <td>0.000851</td>
    </tr>
    <tr>
      <th>DIXON.NS</th>
      <td>0.000562</td>
      <td>0.000086</td>
      <td>0.000100</td>
      <td>0.001805</td>
      <td>0.000857</td>
      <td>0.000734</td>
      <td>0.000555</td>
      <td>-0.000543</td>
      <td>0.000606</td>
      <td>0.000519</td>
      <td>...</td>
      <td>0.004311</td>
      <td>0.000773</td>
      <td>0.002906</td>
      <td>0.000574</td>
      <td>-0.000616</td>
      <td>0.004291</td>
      <td>0.006093</td>
      <td>0.003547</td>
      <td>-0.000646</td>
      <td>0.003068</td>
    </tr>
    <tr>
      <th>ELGIEQUIP.NS</th>
      <td>0.000323</td>
      <td>-0.000777</td>
      <td>-0.001663</td>
      <td>-0.001542</td>
      <td>-0.000591</td>
      <td>0.000456</td>
      <td>0.000238</td>
      <td>-0.000320</td>
      <td>0.000958</td>
      <td>-0.000272</td>
      <td>...</td>
      <td>0.001003</td>
      <td>-0.002070</td>
      <td>0.000032</td>
      <td>0.003898</td>
      <td>-0.002506</td>
      <td>-0.002023</td>
      <td>0.002404</td>
      <td>-0.002499</td>
      <td>0.000305</td>
      <td>0.001033</td>
    </tr>
    <tr>
      <th>FSL.NS</th>
      <td>0.001458</td>
      <td>0.001869</td>
      <td>0.000717</td>
      <td>0.003388</td>
      <td>0.000896</td>
      <td>0.002070</td>
      <td>0.000035</td>
      <td>0.000392</td>
      <td>0.000587</td>
      <td>0.001989</td>
      <td>...</td>
      <td>0.002162</td>
      <td>0.007255</td>
      <td>0.003016</td>
      <td>0.005425</td>
      <td>0.002163</td>
      <td>0.011143</td>
      <td>0.007853</td>
      <td>0.006149</td>
      <td>0.003721</td>
      <td>0.008880</td>
    </tr>
    <tr>
      <th>GRANULES.NS</th>
      <td>-0.000330</td>
      <td>0.000187</td>
      <td>-0.000058</td>
      <td>0.001730</td>
      <td>-0.000550</td>
      <td>0.000916</td>
      <td>0.001376</td>
      <td>-0.000043</td>
      <td>-0.000883</td>
      <td>0.002167</td>
      <td>...</td>
      <td>0.000864</td>
      <td>0.003589</td>
      <td>0.000126</td>
      <td>0.001491</td>
      <td>0.000403</td>
      <td>0.001585</td>
      <td>0.004924</td>
      <td>0.004988</td>
      <td>0.002010</td>
      <td>0.002150</td>
    </tr>
    <tr>
      <th>HIMATSEIDE.NS</th>
      <td>0.000648</td>
      <td>0.000356</td>
      <td>0.000554</td>
      <td>0.002666</td>
      <td>0.000706</td>
      <td>0.002593</td>
      <td>0.000940</td>
      <td>-0.000034</td>
      <td>0.000892</td>
      <td>0.003250</td>
      <td>...</td>
      <td>0.004056</td>
      <td>0.006826</td>
      <td>0.004159</td>
      <td>0.003228</td>
      <td>0.005041</td>
      <td>0.007149</td>
      <td>0.007362</td>
      <td>0.012249</td>
      <td>0.003660</td>
      <td>0.007691</td>
    </tr>
    <tr>
      <th>IDFC.NS</th>
      <td>0.001107</td>
      <td>0.000785</td>
      <td>0.001561</td>
      <td>0.001277</td>
      <td>-0.000386</td>
      <td>0.002433</td>
      <td>0.000281</td>
      <td>0.001424</td>
      <td>0.001047</td>
      <td>0.002703</td>
      <td>...</td>
      <td>0.003014</td>
      <td>0.003163</td>
      <td>0.001653</td>
      <td>0.002557</td>
      <td>0.004791</td>
      <td>0.003375</td>
      <td>0.006301</td>
      <td>0.007255</td>
      <td>0.003447</td>
      <td>0.002818</td>
    </tr>
    <tr>
      <th>L&amp;TFH.NS</th>
      <td>0.002788</td>
      <td>0.001865</td>
      <td>0.002252</td>
      <td>0.001614</td>
      <td>0.001161</td>
      <td>0.001119</td>
      <td>0.001739</td>
      <td>0.002649</td>
      <td>0.001432</td>
      <td>0.002646</td>
      <td>...</td>
      <td>0.004295</td>
      <td>0.003761</td>
      <td>0.001457</td>
      <td>0.002441</td>
      <td>0.005279</td>
      <td>0.004990</td>
      <td>0.005023</td>
      <td>0.002326</td>
      <td>0.003617</td>
      <td>0.003064</td>
    </tr>
    <tr>
      <th>MANAPPURAM.NS</th>
      <td>0.001188</td>
      <td>-0.000747</td>
      <td>0.001826</td>
      <td>0.001706</td>
      <td>-0.000587</td>
      <td>0.003775</td>
      <td>0.000620</td>
      <td>-0.000015</td>
      <td>0.001067</td>
      <td>0.004600</td>
      <td>...</td>
      <td>0.003659</td>
      <td>0.006642</td>
      <td>0.001605</td>
      <td>0.005449</td>
      <td>0.002829</td>
      <td>0.006245</td>
      <td>0.009185</td>
      <td>0.012917</td>
      <td>0.002728</td>
      <td>0.005313</td>
    </tr>
    <tr>
      <th>NBCC.NS</th>
      <td>0.003617</td>
      <td>0.002211</td>
      <td>-0.000642</td>
      <td>0.003446</td>
      <td>0.000695</td>
      <td>0.002483</td>
      <td>0.002025</td>
      <td>-0.000676</td>
      <td>0.001556</td>
      <td>0.002685</td>
      <td>...</td>
      <td>-0.000219</td>
      <td>0.005897</td>
      <td>0.000507</td>
      <td>0.004893</td>
      <td>0.007339</td>
      <td>0.019791</td>
      <td>0.009345</td>
      <td>0.002819</td>
      <td>0.006195</td>
      <td>0.004995</td>
    </tr>
    <tr>
      <th>OBEROIRLTY.NS</th>
      <td>0.002386</td>
      <td>0.001348</td>
      <td>0.002356</td>
      <td>0.000978</td>
      <td>0.001487</td>
      <td>0.002290</td>
      <td>0.001456</td>
      <td>0.002459</td>
      <td>0.003203</td>
      <td>0.003148</td>
      <td>...</td>
      <td>0.003823</td>
      <td>0.003661</td>
      <td>0.001965</td>
      <td>0.003055</td>
      <td>0.005992</td>
      <td>0.000101</td>
      <td>0.006373</td>
      <td>0.004806</td>
      <td>0.000115</td>
      <td>0.002846</td>
    </tr>
    <tr>
      <th>RAYMOND.NS</th>
      <td>0.000889</td>
      <td>0.000881</td>
      <td>0.001558</td>
      <td>0.000673</td>
      <td>-0.000600</td>
      <td>0.000023</td>
      <td>0.000544</td>
      <td>0.001909</td>
      <td>0.002162</td>
      <td>0.001853</td>
      <td>...</td>
      <td>0.003938</td>
      <td>0.002177</td>
      <td>0.000212</td>
      <td>0.003740</td>
      <td>0.002532</td>
      <td>0.004679</td>
      <td>-0.002322</td>
      <td>-0.002649</td>
      <td>0.003194</td>
      <td>0.003333</td>
    </tr>
    <tr>
      <th>SUNTECK.NS</th>
      <td>0.001375</td>
      <td>0.000855</td>
      <td>-0.000520</td>
      <td>0.000607</td>
      <td>-0.000121</td>
      <td>0.000891</td>
      <td>0.001051</td>
      <td>0.000534</td>
      <td>0.000952</td>
      <td>0.002552</td>
      <td>...</td>
      <td>-0.000614</td>
      <td>0.002460</td>
      <td>0.001718</td>
      <td>0.002138</td>
      <td>0.004250</td>
      <td>0.002362</td>
      <td>0.003729</td>
      <td>0.002700</td>
      <td>0.002239</td>
      <td>0.003164</td>
    </tr>
    <tr>
      <th>TV18BRDCST.NS</th>
      <td>0.002784</td>
      <td>0.000708</td>
      <td>0.000427</td>
      <td>0.003117</td>
      <td>-0.002836</td>
      <td>0.001521</td>
      <td>0.001900</td>
      <td>-0.000566</td>
      <td>0.000395</td>
      <td>0.000262</td>
      <td>...</td>
      <td>0.007604</td>
      <td>0.006558</td>
      <td>0.001254</td>
      <td>0.000411</td>
      <td>0.013857</td>
      <td>0.012879</td>
      <td>0.004310</td>
      <td>0.005862</td>
      <td>0.003973</td>
      <td>0.002769</td>
    </tr>
    <tr>
      <th>UNIONBANK.NS</th>
      <td>0.002412</td>
      <td>0.001432</td>
      <td>0.001860</td>
      <td>0.002104</td>
      <td>-0.000424</td>
      <td>0.003917</td>
      <td>0.001850</td>
      <td>-0.000913</td>
      <td>0.002127</td>
      <td>0.003562</td>
      <td>...</td>
      <td>-0.000718</td>
      <td>0.005161</td>
      <td>0.000741</td>
      <td>0.003683</td>
      <td>0.003799</td>
      <td>0.005416</td>
      <td>0.003426</td>
      <td>0.006152</td>
      <td>0.004076</td>
      <td>0.002064</td>
    </tr>
    <tr>
      <th>VBL.NS</th>
      <td>0.000898</td>
      <td>0.000798</td>
      <td>0.000726</td>
      <td>-0.000045</td>
      <td>0.001896</td>
      <td>0.000628</td>
      <td>0.000635</td>
      <td>0.000151</td>
      <td>0.000879</td>
      <td>0.000054</td>
      <td>...</td>
      <td>-0.001240</td>
      <td>-0.000735</td>
      <td>0.001645</td>
      <td>0.001953</td>
      <td>-0.000592</td>
      <td>0.000854</td>
      <td>0.005370</td>
      <td>0.000540</td>
      <td>-0.002620</td>
      <td>0.000603</td>
    </tr>
    <tr>
      <th>YESBANK.NS</th>
      <td>0.001249</td>
      <td>-0.000066</td>
      <td>0.000821</td>
      <td>0.000115</td>
      <td>0.000848</td>
      <td>0.001618</td>
      <td>-0.000619</td>
      <td>0.000605</td>
      <td>0.001512</td>
      <td>0.002203</td>
      <td>...</td>
      <td>0.001054</td>
      <td>0.000784</td>
      <td>0.000683</td>
      <td>0.002918</td>
      <td>0.001370</td>
      <td>0.008640</td>
      <td>0.007584</td>
      <td>0.003840</td>
      <td>0.001116</td>
      <td>0.002197</td>
    </tr>
    <tr>
      <th>ZEEL.NS</th>
      <td>0.002663</td>
      <td>0.000860</td>
      <td>0.002680</td>
      <td>0.001998</td>
      <td>0.000836</td>
      <td>0.000247</td>
      <td>0.000551</td>
      <td>0.004922</td>
      <td>0.004565</td>
      <td>0.002834</td>
      <td>...</td>
      <td>0.006670</td>
      <td>0.003820</td>
      <td>0.001138</td>
      <td>0.006380</td>
      <td>0.003953</td>
      <td>-0.002787</td>
      <td>0.001935</td>
      <td>0.002961</td>
      <td>0.003036</td>
      <td>0.002039</td>
    </tr>
    <tr>
      <th>AJANTPHARM.NS</th>
      <td>0.000974</td>
      <td>0.000984</td>
      <td>0.000483</td>
      <td>0.001460</td>
      <td>0.000055</td>
      <td>0.000512</td>
      <td>0.001112</td>
      <td>0.000458</td>
      <td>-0.000294</td>
      <td>0.001971</td>
      <td>...</td>
      <td>0.002080</td>
      <td>0.003115</td>
      <td>0.001110</td>
      <td>0.003600</td>
      <td>0.001137</td>
      <td>0.004007</td>
      <td>0.004112</td>
      <td>0.002662</td>
      <td>0.003053</td>
      <td>0.002758</td>
    </tr>
    <tr>
      <th>BLUESTARCO.NS</th>
      <td>0.000927</td>
      <td>-0.000287</td>
      <td>-0.000865</td>
      <td>0.000309</td>
      <td>-0.001220</td>
      <td>0.000507</td>
      <td>0.000010</td>
      <td>0.000688</td>
      <td>0.000667</td>
      <td>0.001397</td>
      <td>...</td>
      <td>0.000470</td>
      <td>-0.001582</td>
      <td>-0.001149</td>
      <td>0.001065</td>
      <td>0.000027</td>
      <td>0.003079</td>
      <td>0.002739</td>
      <td>0.001170</td>
      <td>0.000578</td>
      <td>0.000225</td>
    </tr>
    <tr>
      <th>CENTURYPLY.NS</th>
      <td>0.001609</td>
      <td>0.000175</td>
      <td>0.001577</td>
      <td>0.001654</td>
      <td>-0.000617</td>
      <td>0.000905</td>
      <td>0.001519</td>
      <td>0.001827</td>
      <td>0.001645</td>
      <td>0.001930</td>
      <td>...</td>
      <td>0.009462</td>
      <td>0.003185</td>
      <td>0.001975</td>
      <td>0.002296</td>
      <td>0.004018</td>
      <td>0.002749</td>
      <td>0.002450</td>
      <td>0.002771</td>
      <td>0.001762</td>
      <td>0.004243</td>
    </tr>
    <tr>
      <th>DALMIASUG.NS</th>
      <td>0.000431</td>
      <td>0.000982</td>
      <td>0.000858</td>
      <td>0.002319</td>
      <td>0.000476</td>
      <td>0.001345</td>
      <td>0.000759</td>
      <td>-0.000768</td>
      <td>-0.000208</td>
      <td>0.001907</td>
      <td>...</td>
      <td>0.003185</td>
      <td>0.020801</td>
      <td>0.001536</td>
      <td>0.003737</td>
      <td>0.010620</td>
      <td>0.008108</td>
      <td>0.000794</td>
      <td>0.010396</td>
      <td>0.005978</td>
      <td>0.009913</td>
    </tr>
    <tr>
      <th>EMAMILTD.NS</th>
      <td>-0.000054</td>
      <td>0.000819</td>
      <td>0.000678</td>
      <td>0.000497</td>
      <td>0.001948</td>
      <td>0.000288</td>
      <td>0.000066</td>
      <td>-0.000158</td>
      <td>0.000397</td>
      <td>0.001371</td>
      <td>...</td>
      <td>0.001975</td>
      <td>0.001536</td>
      <td>0.005949</td>
      <td>0.002176</td>
      <td>0.000944</td>
      <td>0.002767</td>
      <td>0.003383</td>
      <td>0.002121</td>
      <td>-0.000953</td>
      <td>0.003403</td>
    </tr>
    <tr>
      <th>FINCABLES.NS</th>
      <td>0.000872</td>
      <td>0.000569</td>
      <td>0.001286</td>
      <td>0.000799</td>
      <td>0.000281</td>
      <td>0.000915</td>
      <td>0.000362</td>
      <td>0.001708</td>
      <td>0.001350</td>
      <td>0.002957</td>
      <td>...</td>
      <td>0.002296</td>
      <td>0.003737</td>
      <td>0.002176</td>
      <td>0.013892</td>
      <td>-0.002915</td>
      <td>0.003646</td>
      <td>0.003624</td>
      <td>0.001654</td>
      <td>0.002618</td>
      <td>0.006348</td>
    </tr>
    <tr>
      <th>GMDCLTD.NS</th>
      <td>0.002376</td>
      <td>0.001265</td>
      <td>0.001204</td>
      <td>0.001665</td>
      <td>-0.001673</td>
      <td>0.002367</td>
      <td>0.002256</td>
      <td>0.001458</td>
      <td>0.002000</td>
      <td>0.001959</td>
      <td>...</td>
      <td>0.004018</td>
      <td>0.010620</td>
      <td>0.000944</td>
      <td>-0.002915</td>
      <td>0.028269</td>
      <td>0.008477</td>
      <td>0.004050</td>
      <td>0.003259</td>
      <td>0.004876</td>
      <td>-0.000126</td>
    </tr>
    <tr>
      <th>HCC.NS</th>
      <td>0.000919</td>
      <td>0.001659</td>
      <td>-0.000995</td>
      <td>0.005840</td>
      <td>0.000011</td>
      <td>0.000121</td>
      <td>-0.000385</td>
      <td>-0.002880</td>
      <td>-0.002323</td>
      <td>0.001799</td>
      <td>...</td>
      <td>0.002749</td>
      <td>0.008108</td>
      <td>0.002767</td>
      <td>0.003646</td>
      <td>0.008477</td>
      <td>0.043384</td>
      <td>0.012691</td>
      <td>0.004345</td>
      <td>0.007304</td>
      <td>0.011184</td>
    </tr>
    <tr>
      <th>ITDCEM.NS</th>
      <td>0.001187</td>
      <td>-0.000111</td>
      <td>0.001032</td>
      <td>0.001510</td>
      <td>0.001636</td>
      <td>0.003664</td>
      <td>0.001902</td>
      <td>0.001026</td>
      <td>0.001331</td>
      <td>0.002540</td>
      <td>...</td>
      <td>0.002450</td>
      <td>0.000794</td>
      <td>0.003383</td>
      <td>0.003624</td>
      <td>0.004050</td>
      <td>0.012691</td>
      <td>0.021661</td>
      <td>0.004115</td>
      <td>-0.000042</td>
      <td>0.006852</td>
    </tr>
    <tr>
      <th>JSL.NS</th>
      <td>-0.000372</td>
      <td>0.000036</td>
      <td>0.000605</td>
      <td>0.003163</td>
      <td>-0.001881</td>
      <td>0.002885</td>
      <td>-0.000542</td>
      <td>-0.002603</td>
      <td>-0.001227</td>
      <td>0.003399</td>
      <td>...</td>
      <td>0.002771</td>
      <td>0.010396</td>
      <td>0.002121</td>
      <td>0.001654</td>
      <td>0.003259</td>
      <td>0.004345</td>
      <td>0.004115</td>
      <td>0.025722</td>
      <td>0.002564</td>
      <td>0.004950</td>
    </tr>
    <tr>
      <th>KSCL.NS</th>
      <td>0.001434</td>
      <td>0.000529</td>
      <td>0.000286</td>
      <td>0.001524</td>
      <td>-0.001548</td>
      <td>0.000868</td>
      <td>-0.000157</td>
      <td>0.000702</td>
      <td>0.000358</td>
      <td>0.001453</td>
      <td>...</td>
      <td>0.001762</td>
      <td>0.005978</td>
      <td>-0.000953</td>
      <td>0.002618</td>
      <td>0.004876</td>
      <td>0.007304</td>
      <td>-0.000042</td>
      <td>0.002564</td>
      <td>0.008839</td>
      <td>0.005238</td>
    </tr>
    <tr>
      <th>LUXIND.NS</th>
      <td>0.001533</td>
      <td>0.000912</td>
      <td>0.001541</td>
      <td>0.001753</td>
      <td>0.000842</td>
      <td>0.003122</td>
      <td>0.000551</td>
      <td>0.000530</td>
      <td>0.001117</td>
      <td>0.003104</td>
      <td>...</td>
      <td>0.004243</td>
      <td>0.009913</td>
      <td>0.003403</td>
      <td>0.006348</td>
      <td>-0.000126</td>
      <td>0.011184</td>
      <td>0.006852</td>
      <td>0.004950</td>
      <td>0.005238</td>
      <td>0.020924</td>
    </tr>
  </tbody>
</table>
<p>52 rows × 52 columns</p>
</div>




```python
# no of stocks with negative mean returns
(monthly_returns.mean()<0).sum()
```




    5




```python

```


```python
class PortfolioOptimizer:
    
    def __init__(self, returns, risk_free_rate, allow_shortselling=False):
        """
        Initializes the portfolio optimizer with returns data, risk-free rate, and short selling option.
        
        :param returns: A DataFrame containing return series for each asset.
        :param risk_free_rate: Annual risk-free rate, adjusted to match the returns period within methods.
        :param allow_shortselling: Boolean flag to allow or disallow short selling in the portfolio.
        """
        self.returns = returns
        self.n = returns.shape[1]  # Number of assets
        self.mean_returns = returns.mean().values  # Average returns for each asset
        self.cov_matrix = returns.cov().values  # Covariance matrix of returns
        self.risk_free_rate = risk_free_rate / 12  # Convert annual risk-free rate to monthly
        self.allow_shortselling = allow_shortselling
        # Attributes to be defined by child classes or methods
        self.best_weights = None
        self.max_sharpe_return = None
        self.max_sharpe_volatility = None

    def portfolio_variance(self, weights):
        """Calculates the portfolio variance given a set of weights."""
        return np.dot(weights.T, np.dot(self.cov_matrix, weights))

    def portfolio_return(self, weights):
        """Calculates the expected portfolio return given a set of weights."""
        return np.dot(weights, self.mean_returns)
    
    def get_optimal_weights(self, target_return):
        """
        Finds the weights of the portfolio that has a return closest to the target_return.
        
        :param target_return: The desired return to match.
        :return: A tuple containing the weights of the closest portfolio and its Sharpe ratio.
        """
        if not hasattr(self, 'target_returns') or not hasattr(self, 'optimal_weights') or not hasattr(self, 'risks'):
            raise Exception("Efficient frontier not generated yet.")
        
        # Find the index of the portfolio with a return closest to the target return
        idx = np.abs(np.array(self.target_returns) - target_return).argmin()
        optimal_weight = self.optimal_weights[idx]
        portfolio_return = self.target_returns[idx]
        portfolio_risk = self.risks[idx]
        # Calculate the Sharpe ratio for the selected portfolio
        sharpe_ratio = (portfolio_return - self.risk_free_rate) / portfolio_risk

        return optimal_weight, sharpe_ratio
    
    def get_min_variance_portfolio(self,min_return_threshold=0.02):
        # Identify the index of the portfolio with the minimum risk (variance)
        min_var_idx = np.argmin(self.risks)

        # Use the correct attribute depending on the class instance
        if hasattr(self, 'optimal_weights'):
            min_var_weights = self.optimal_weights[min_var_idx]
        elif hasattr(self, 'weights_array'):
            min_var_weights = self.weights_array[min_var_idx]
        else:
            raise AttributeError("This object does not have portfolio weights data.")

        min_var_return = self.target_returns[min_var_idx] if hasattr(self, 'target_returns') else self.returns_array[min_var_idx]
        min_var_risk = np.sqrt(self.risks[min_var_idx])

        # Compile the portfolio summary
        portfolio_summary = "Global Minimum Variance Portfolio:\n"
        portfolio_summary += f"Expected Return: {min_return_threshold:.4f}\n"
        portfolio_summary += f"Risk (Volatility): {min_var_risk:.4f}\n"
        portfolio_summary += "Weights:\n"

        # Adjust here to use column names from the returns DataFrame as stock names
        stock_names = self.returns.columns if isinstance(self.returns, pd.DataFrame) else [f"Asset {i+1}" for i in range(len(min_var_weights))]

        for stock_name, weight in zip(stock_names, min_var_weights):
            portfolio_summary += f"{stock_name}: {weight:.4f}\n"

        print(portfolio_summary)  # Print the compiled summary

        # Return weights in a dictionary format
        weights_dict = {stock_name: weight for stock_name, weight in zip(stock_names, min_var_weights)}

        return min_var_return, min_var_risk, weights_dict

    def print_best_portfolio_summary(self):
        """
        Prints a summary of the best portfolio based on the Sharpe ratio, including asset weights,
        expected return, risk (volatility), and Sharpe ratio.
        """
        if self.best_weights is None or self.max_sharpe_return is None or self.max_sharpe_volatility is None:
            print("Optimization must be run first to generate summary.")
            return
        
        print("Best portfolio weights:")
        for i, weight in enumerate(self.best_weights):
            stock_name = self.returns.columns[i] if isinstance(self.returns, pd.DataFrame) else f"Asset {i}"
            print(f"{stock_name}: {weight:.4f}")
        
        print(f"Expected monthly return: {self.max_sharpe_return * 100:.2f}%")
        print(f"Monthly risk (volatility): {self.max_sharpe_volatility * 100:.2f}%")
        max_sharpe_ratio = (self.max_sharpe_return - self.risk_free_rate) / self.max_sharpe_volatility
        print(f"Best Sharpe ratio: {max_sharpe_ratio:.4f}")

        
class QuadraticOptimisation(PortfolioOptimizer):
    """Optimizes portfolio using a quadratic programming approach."""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Automatically generate the efficient frontier upon initialization
        self.generate_efficient_frontier()

    def solve_portfolio(self, target_return):
        """
        Solves for the portfolio with minimum variance given a target return using cvxpy.

        :param target_return: The target return for which the portfolio variance is minimized.
        :return: Optimized weights and the portfolio variance.
        """
        # Define the optimization variables
        weights = cp.Variable(self.n)

        # The portfolio variance can be expressed as a quadratic form
        portfolio_variance = cp.quad_form(weights, self.cov_matrix)

        # The expected return is the weights' dot product with the mean returns
        expected_return = weights @ self.mean_returns

        # Constraints include the weights summing to 1 and achieving the target return
        constraints = [cp.sum(weights) == 1, expected_return >= target_return]

        # If short selling is not allowed, add constraints for weights to be non-negative
        if not self.allow_shortselling:
            constraints += [weights >= 0]

        # Define the problem and objective
        problem = cp.Problem(cp.Minimize(portfolio_variance), constraints)

        problem.solve(solver=cp.ECOS,abstol=1e-5, reltol=1e-5, feastol=1e-5)
         
    
        # Check if the optimization was successful
        if problem.status not in ["infeasible", "unbounded"]:
            # If successful, return the optimized weights and the standard deviation (square root of variance)
            optimized_weights = weights.value
            min_variance = portfolio_variance.value
            return optimized_weights, np.sqrt(min_variance)
        else:
            # If not successful, raise an exception
            raise ValueError("Optimization failed: ", problem.status)




    

    def generate_efficient_frontier(self, steps=100):
        """
        Generates the efficient frontier by solving the portfolio optimization problem across a range
        of target returns.

        :param steps: Number of points to calculate along the efficient frontier.
        """
        # Determine the range of target returns from the minimum to maximum historical returns
        self.min_return = np.min(self.mean_returns)
        self.max_return = np.max(self.mean_returns)
        target_returns = np.linspace(self.min_return, self.max_return, steps)
        
        # Initialize lists to store risks (volatilities) and weights for each point on the frontier
        risks = []
        optimal_weights = []

        # For each target return, solve the optimization problem to find the minimum variance portfolio
        for target_return in target_returns:
            weights, risk = self.solve_portfolio(target_return)
            risks.append(np.sqrt(risk))
            optimal_weights.append(weights)

        # Store the results as attributes for access by other methods
        self.risks = risks
        self.optimal_weights = optimal_weights
        self.target_returns = target_returns

        # Calculate the Sharpe ratio for each portfolio on the efficient frontier
        sharpe_ratios = (self.target_returns - self.risk_free_rate) / self.risks
        self.max_sharpe_ratio = np.max(sharpe_ratios)
        max_sharpe_idx = np.argmax(sharpe_ratios)
        # Identify the portfolio with the maximum Sharpe ratio as the "best" portfolio
        self.best_weights = self.optimal_weights[max_sharpe_idx]

        # Calculate the tangent point for the Capital Market Line (CML)
        self.cml_risk = self.risks[max_sharpe_idx]
        self.cml_return = self.target_returns[max_sharpe_idx]
        self.cml_tangent_point = (self.cml_risk, self.cml_return)
        self.sharpe_ratio = sharpe_ratios[max_sharpe_idx]
    
    def plot_efficient_frontier(self, min_return_threshold=0.02, extension_factor=2):
        """
        Plots the efficient frontier along with the Capital Market Line (CML).

        :param min_return_threshold: Minimum return threshold for plotting.
        :param extension_factor: How far to extend the CML beyond the tangent point.
        """
        sns.set(style="whitegrid")
        plt.figure(figsize=(10, 6))

        # Filter out points below the return threshold for clearer visualization
        filtered_risks = [risk for risk, ret in zip(self.risks, self.target_returns) if ret >= min_return_threshold]
        filtered_returns = [ret for ret in self.target_returns if ret >= min_return_threshold]
        plt.scatter(filtered_risks, filtered_returns, label='Efficient Frontier', marker='o', s=2, linewidths=2)

        # Plot the CML using the tangent point and extending it for visualization
        plt.plot([0, self.cml_tangent_point[0]], [self.risk_free_rate, self.cml_tangent_point[1]], linestyle='--', color='red', label=f'CML (Sharpe Ratio: {self.sharpe_ratio:.2f})')
        plt.plot(*self.cml_tangent_point, marker='*', markersize=5, color='red', label='Tangent Point')

        # Extending the CML for better visualization
        cml_extension_risks = np.linspace(0, extension_factor * self.cml_tangent_point[0], 100)
        cml_extension_returns = self.risk_free_rate + (self.cml_tangent_point[1] - self.risk_free_rate) / self.cml_tangent_point[0] * cml_extension_risks
        plt.plot(cml_extension_risks, cml_extension_returns, linestyle='--', color='orange', label='Extended CML')

        plt.title('Efficient Frontier with Extended CML')
        plt.xlabel('Risk (Volatility)')
        plt.ylabel('Expected Return')
        plt.legend(loc='upper left')
        plt.show()
        
class MonteCarloOptimization(PortfolioOptimizer):
    """Performs portfolio optimization using Monte Carlo simulation to sample portfolio weights."""
    
    def __init__(self, num_portfolios=10000,*args, **kwargs):
        """
        Initializes the Monte Carlo simulation with a specified number of portfolios to sample.
        
        :param num_portfolios: The number of random portfolios to generate for the simulation.
        """
        super().__init__(*args, **kwargs)
        self.num_portfolios = num_portfolios
        self.simulate_portfolios()  # Start simulation upon initialization
    

    def simulate_portfolios(self):
        """
        Simulates a number of random portfolios to estimate the efficient frontier.
        """
        np.random.seed(42)  # Ensure reproducibility
        # Initialize arrays to store portfolio returns, volatilities, and Sharpe ratios
        self.risks = np.zeros(self.num_portfolios)
        self.returns_array = np.zeros(self.num_portfolios)
        self.sharpe_ratios = np.zeros(self.num_portfolios)
        self.weights_array = np.zeros((self.num_portfolios, self.n))

        for i in range(self.num_portfolios):
            # Generate random weights
            weights = np.random.uniform(-1, 1, self.n) if self.allow_shortselling else np.random.uniform(0, 1, self.n)
            weights /= np.sum(np.abs(weights))  # Normalize weights to sum to 1 (or -1 to 1 for short selling)

            # Calculate portfolio statistics
            portfolio_return = self.portfolio_return(weights)
            portfolio_variance = self.portfolio_variance(weights)
            portfolio_risk = np.sqrt(portfolio_variance)
            sharpe_ratio = (portfolio_return - self.risk_free_rate) / portfolio_risk

            # Store statistics
            self.returns_array[i] = portfolio_return
            self.risks[i] = portfolio_risk
            self.sharpe_ratios[i] = sharpe_ratio
            self.weights_array[i] = weights

        # Identify the portfolio with the maximum Sharpe ratio
        self.max_sharpe_idx = np.argmax(self.sharpe_ratios)
        self.max_sharpe_return = self.returns_array[self.max_sharpe_idx]
        self.max_sharpe_volatility = self.risks[self.max_sharpe_idx]
        self.best_weights = self.weights_array[self.max_sharpe_idx]

  
    def generate_efficient_frontier(self, min_return_threshold=0.02, extension_factor=2):
        """
        Plots the efficient frontier based on Monte Carlo simulation results,
        along with the Capital Market Line (CML).
        
        """
        
        # The risk (volatility) and return at the maximum Sharpe ratio serve as the tangent point for the CML
        self.cml_risk = self.max_sharpe_volatility
        self.cml_return = self.max_sharpe_return
        self.cml_tangent_point = (self.cml_risk, self.cml_return)
        
        # The maximum Sharpe ratio calculated during simulation
        self.sharpe_ratio = self.sharpe_ratios[self.max_sharpe_idx]
        plt.figure(figsize=(10, 6))
        plt.scatter(self.risks, self.returns_array, c=self.sharpe_ratios, cmap='viridis', label='Simulated Portfolios')
        plt.colorbar(label='Sharpe Ratio')

        # Plot the marker for the maximum Sharpe ratio point with a custom label
        plt.scatter(self.cml_risk, self.cml_return, marker='*', color='r', s=500, label=f'Max Sharpe Ratio: {self.sharpe_ratio:.4f}')

        # Plot the Capital Market Line (CML) if cml_tangent_point exists
        if hasattr(self, 'cml_tangent_point'):
            slope = (self.cml_return - self.risk_free_rate) / self.cml_risk
            intercept = self.risk_free_rate
            cml_x = np.linspace(0, self.cml_risk * extension_factor, 100)
            cml_y = slope * cml_x + intercept
            plt.plot(cml_x, cml_y, '--', color='red', label='Capital Market Line')

        plt.title('Monte Carlo Simulation: Efficient Frontier and CML')
        plt.xlabel('Volatility (Risk)')
        plt.ylabel('Expected Return')
        plt.legend()
        plt.show()


```


```python
model = MonteCarloOptimization(returns=monthly_returns, risk_free_rate=0.05,allow_shortselling=False)

```


```python
model.generate_efficient_frontier()
```


    
![png](output_8_0.png)
    



```python
model.print_best_portfolio_summary()
```

    Best portfolio weights:
    RELIANCE.NS: 0.0351
    TCS.NS: 0.0278
    HDFCBANK.NS: 0.0007
    INFY.NS: 0.0094
    HINDUNILVR.NS: 0.0159
    ICICIBANK.NS: 0.0245
    BHARTIARTL.NS: 0.0262
    ITC.NS: 0.0241
    KOTAKBANK.NS: 0.0028
    LT.NS: 0.0298
    GODREJCP.NS: 0.0264
    FEDERALBNK.NS: 0.0084
    TATAPOWER.NS: 0.0195
    APOLLOHOSP.NS: 0.0101
    ASHOKLEY.NS: 0.0270
    MUTHOOTFIN.NS: 0.0085
    JUBLFOOD.NS: 0.0008
    BIOCON.NS: 0.0170
    CROMPTON.NS: 0.0017
    VMART.NS: 0.0017
    KEC.NS: 0.0075
    BAJAJELEC.NS: 0.0284
    CHALET.NS: 0.0371
    DIXON.NS: 0.0202
    ELGIEQUIP.NS: 0.0267
    FSL.NS: 0.0020
    GRANULES.NS: 0.0311
    HIMATSEIDE.NS: 0.0177
    IDFC.NS: 0.0190
    L&TFH.NS: 0.0316
    MANAPPURAM.NS: 0.0046
    NBCC.NS: 0.0179
    OBEROIRLTY.NS: 0.0212
    RAYMOND.NS: 0.0242
    SUNTECK.NS: 0.0279
    TV18BRDCST.NS: 0.0249
    UNIONBANK.NS: 0.0334
    VBL.NS: 0.0387
    YESBANK.NS: 0.0007
    ZEEL.NS: 0.0163
    AJANTPHARM.NS: 0.0161
    BLUESTARCO.NS: 0.0296
    CENTURYPLY.NS: 0.0114
    DALMIASUG.NS: 0.0006
    EMAMILTD.NS: 0.0029
    FINCABLES.NS: 0.0364
    GMDCLTD.NS: 0.0362
    HCC.NS: 0.0101
    ITDCEM.NS: 0.0369
    JSL.NS: 0.0345
    KSCL.NS: 0.0271
    LUXIND.NS: 0.0096
    Expected monthly return: 3.08%
    Monthly risk (volatility): 4.60%
    Best Sharpe ratio: 0.5793
    


```python
model.get_min_variance_portfolio()
```

    Global Minimum Variance Portfolio:
    Expected Return: 0.0200
    Risk (Volatility): 0.2003
    Weights:
    RELIANCE.NS: 0.0059
    TCS.NS: 0.0331
    HDFCBANK.NS: 0.0425
    INFY.NS: 0.0150
    HINDUNILVR.NS: 0.0165
    ICICIBANK.NS: 0.0038
    BHARTIARTL.NS: 0.0289
    ITC.NS: 0.0249
    KOTAKBANK.NS: 0.0018
    LT.NS: 0.0339
    GODREJCP.NS: 0.0374
    FEDERALBNK.NS: 0.0409
    TATAPOWER.NS: 0.0246
    APOLLOHOSP.NS: 0.0204
    ASHOKLEY.NS: 0.0395
    MUTHOOTFIN.NS: 0.0180
    JUBLFOOD.NS: 0.0295
    BIOCON.NS: 0.0277
    CROMPTON.NS: 0.0168
    VMART.NS: 0.0039
    KEC.NS: 0.0010
    BAJAJELEC.NS: 0.0193
    CHALET.NS: 0.0217
    DIXON.NS: 0.0371
    ELGIEQUIP.NS: 0.0187
    FSL.NS: 0.0127
    GRANULES.NS: 0.0208
    HIMATSEIDE.NS: 0.0107
    IDFC.NS: 0.0041
    L&TFH.NS: 0.0051
    MANAPPURAM.NS: 0.0144
    NBCC.NS: 0.0006
    OBEROIRLTY.NS: 0.0099
    RAYMOND.NS: 0.0355
    SUNTECK.NS: 0.0106
    TV18BRDCST.NS: 0.0050
    UNIONBANK.NS: 0.0428
    VBL.NS: 0.0280
    YESBANK.NS: 0.0027
    ZEEL.NS: 0.0028
    AJANTPHARM.NS: 0.0276
    BLUESTARCO.NS: 0.0243
    CENTURYPLY.NS: 0.0031
    DALMIASUG.NS: 0.0101
    EMAMILTD.NS: 0.0419
    FINCABLES.NS: 0.0258
    GMDCLTD.NS: 0.0198
    HCC.NS: 0.0113
    ITDCEM.NS: 0.0060
    JSL.NS: 0.0181
    KSCL.NS: 0.0416
    LUXIND.NS: 0.0022
    
    




    (0.02441403835426536,
     0.2002869439229097,
     {'RELIANCE.NS': 0.00591546381689457,
      'TCS.NS': 0.03307031756695078,
      'HDFCBANK.NS': 0.04249190923792199,
      'INFY.NS': 0.014955062328376154,
      'HINDUNILVR.NS': 0.016507561491867575,
      'ICICIBANK.NS': 0.0037648491227709586,
      'BHARTIARTL.NS': 0.028906437578793125,
      'ITC.NS': 0.024894095341977986,
      'KOTAKBANK.NS': 0.0018180285008654706,
      'LT.NS': 0.03389558027150214,
      'GODREJCP.NS': 0.03736855857864356,
      'FEDERALBNK.NS': 0.04087590234605334,
      'TATAPOWER.NS': 0.024591435474877556,
      'APOLLOHOSP.NS': 0.02039380168389254,
      'ASHOKLEY.NS': 0.03947979583610156,
      'MUTHOOTFIN.NS': 0.017965759054836383,
      'JUBLFOOD.NS': 0.029535056962921476,
      'BIOCON.NS': 0.027728964720057286,
      'CROMPTON.NS': 0.016770027572704568,
      'VMART.NS': 0.003915365279938709,
      'KEC.NS': 0.0009650099759670147,
      'BAJAJELEC.NS': 0.019296908569845984,
      'CHALET.NS': 0.021683522758697393,
      'DIXON.NS': 0.03707087400520166,
      'ELGIEQUIP.NS': 0.01867388826735103,
      'FSL.NS': 0.012669402723492026,
      'GRANULES.NS': 0.020822623628984266,
      'HIMATSEIDE.NS': 0.010724137801340187,
      'IDFC.NS': 0.004116819216742734,
      'L&TFH.NS': 0.005093855302831661,
      'MANAPPURAM.NS': 0.014381484510426208,
      'NBCC.NS': 0.0005712146489320726,
      'OBEROIRLTY.NS': 0.00992262541959751,
      'RAYMOND.NS': 0.03548674161275561,
      'SUNTECK.NS': 0.010572133379887268,
      'TV18BRDCST.NS': 0.004989605184825417,
      'UNIONBANK.NS': 0.04276671357535208,
      'VBL.NS': 0.02804925345365726,
      'YESBANK.NS': 0.002704841606510684,
      'ZEEL.NS': 0.0028047881276765775,
      'AJANTPHARM.NS': 0.027582960526620293,
      'BLUESTARCO.NS': 0.024338854619297048,
      'CENTURYPLY.NS': 0.003081049628418792,
      'DALMIASUG.NS': 0.010107925578792691,
      'EMAMILTD.NS': 0.04186379312546881,
      'FINCABLES.NS': 0.025775496332985082,
      'GMDCLTD.NS': 0.019841592986215496,
      'HCC.NS': 0.0112723042720252,
      'ITDCEM.NS': 0.006024594878165372,
      'JSL.NS': 0.018143068814750786,
      'KSCL.NS': 0.04156294851791264,
      'LUXIND.NS': 0.002194994181325403})




```python
model1= MonteCarloOptimization(returns=monthly_returns, risk_free_rate=0.05,allow_shortselling=True)
```


```python
model1.generate_efficient_frontier()
```


    
![png](output_12_0.png)
    



```python
#abs mod weights sum to 1
(np.abs(model1.best_weights)).sum()
```




    1.0000000000000002




```python
model1.print_best_portfolio_summary()
```

    Best portfolio weights:
    RELIANCE.NS: 0.0097
    TCS.NS: -0.0046
    HDFCBANK.NS: 0.0128
    INFY.NS: 0.0087
    HINDUNILVR.NS: -0.0370
    ICICIBANK.NS: 0.0231
    BHARTIARTL.NS: 0.0113
    ITC.NS: -0.0054
    KOTAKBANK.NS: -0.0248
    LT.NS: -0.0266
    GODREJCP.NS: 0.0328
    FEDERALBNK.NS: -0.0196
    TATAPOWER.NS: 0.0239
    APOLLOHOSP.NS: -0.0118
    ASHOKLEY.NS: -0.0264
    MUTHOOTFIN.NS: 0.0220
    JUBLFOOD.NS: -0.0300
    BIOCON.NS: -0.0341
    CROMPTON.NS: 0.0109
    VMART.NS: 0.0138
    KEC.NS: -0.0071
    BAJAJELEC.NS: -0.0278
    CHALET.NS: 0.0077
    DIXON.NS: 0.0344
    ELGIEQUIP.NS: 0.0073
    FSL.NS: 0.0371
    GRANULES.NS: 0.0150
    HIMATSEIDE.NS: -0.0285
    IDFC.NS: 0.0175
    L&TFH.NS: -0.0261
    MANAPPURAM.NS: -0.0012
    NBCC.NS: -0.0168
    OBEROIRLTY.NS: 0.0315
    RAYMOND.NS: 0.0143
    SUNTECK.NS: 0.0306
    TV18BRDCST.NS: 0.0030
    UNIONBANK.NS: 0.0278
    VBL.NS: 0.0343
    YESBANK.NS: -0.0036
    ZEEL.NS: 0.0029
    AJANTPHARM.NS: 0.0304
    BLUESTARCO.NS: 0.0150
    CENTURYPLY.NS: -0.0160
    DALMIASUG.NS: 0.0028
    EMAMILTD.NS: -0.0377
    FINCABLES.NS: 0.0217
    GMDCLTD.NS: 0.0324
    HCC.NS: 0.0335
    ITDCEM.NS: -0.0097
    JSL.NS: 0.0003
    KSCL.NS: -0.0348
    LUXIND.NS: -0.0016
    Expected monthly return: 1.31%
    Monthly risk (volatility): 1.58%
    Best Sharpe ratio: 0.5650
    


```python
model1.get_min_variance_portfolio()
```

    Global Minimum Variance Portfolio:
    Expected Return: 0.0200
    Risk (Volatility): 0.0910
    Weights:
    RELIANCE.NS: 0.0206
    TCS.NS: -0.0013
    HDFCBANK.NS: -0.0310
    INFY.NS: 0.0266
    HINDUNILVR.NS: -0.0327
    ICICIBANK.NS: 0.0321
    BHARTIARTL.NS: -0.0081
    ITC.NS: 0.0297
    KOTAKBANK.NS: 0.0299
    LT.NS: 0.0137
    GODREJCP.NS: -0.0123
    FEDERALBNK.NS: 0.0187
    TATAPOWER.NS: -0.0205
    APOLLOHOSP.NS: -0.0065
    ASHOKLEY.NS: 0.0017
    MUTHOOTFIN.NS: -0.0312
    JUBLFOOD.NS: 0.0208
    BIOCON.NS: -0.0038
    CROMPTON.NS: -0.0013
    VMART.NS: -0.0144
    KEC.NS: -0.0115
    BAJAJELEC.NS: 0.0022
    CHALET.NS: 0.0156
    DIXON.NS: 0.0067
    ELGIEQUIP.NS: -0.0199
    FSL.NS: -0.0305
    GRANULES.NS: 0.0244
    HIMATSEIDE.NS: 0.0228
    IDFC.NS: -0.0176
    L&TFH.NS: 0.0124
    MANAPPURAM.NS: -0.0283
    NBCC.NS: 0.0304
    OBEROIRLTY.NS: 0.0325
    RAYMOND.NS: -0.0064
    SUNTECK.NS: -0.0186
    TV18BRDCST.NS: -0.0316
    UNIONBANK.NS: 0.0336
    VBL.NS: -0.0263
    YESBANK.NS: -0.0088
    ZEEL.NS: -0.0256
    AJANTPHARM.NS: -0.0311
    BLUESTARCO.NS: -0.0270
    CENTURYPLY.NS: 0.0269
    DALMIASUG.NS: -0.0123
    EMAMILTD.NS: -0.0200
    FINCABLES.NS: -0.0075
    GMDCLTD.NS: 0.0048
    HCC.NS: 0.0288
    ITDCEM.NS: -0.0096
    JSL.NS: 0.0243
    KSCL.NS: -0.0353
    LUXIND.NS: 0.0098
    
    




    (0.0020755314416759096,
     0.09101856932370031,
     {'RELIANCE.NS': 0.02055665213439788,
      'TCS.NS': -0.0012567431832372002,
      'HDFCBANK.NS': -0.031019007423319034,
      'INFY.NS': 0.026585710210660547,
      'HINDUNILVR.NS': -0.03268074966361102,
      'ICICIBANK.NS': 0.03214834628241328,
      'BHARTIARTL.NS': -0.008059752632880422,
      'ITC.NS': 0.029684489371181948,
      'KOTAKBANK.NS': 0.02987655106658714,
      'LT.NS': 0.01368857822238971,
      'GODREJCP.NS': -0.012341027719156517,
      'FEDERALBNK.NS': 0.018669066137936303,
      'TATAPOWER.NS': -0.02050749457604819,
      'APOLLOHOSP.NS': -0.006532218898913109,
      'ASHOKLEY.NS': 0.0016632085693424298,
      'MUTHOOTFIN.NS': -0.031222571084507336,
      'JUBLFOOD.NS': 0.020798432008023063,
      'BIOCON.NS': -0.0037749743055532897,
      'CROMPTON.NS': -0.0013372257773278176,
      'VMART.NS': -0.014440995339395085,
      'KEC.NS': -0.011517985248023293,
      'BAJAJELEC.NS': 0.0022357250497198975,
      'CHALET.NS': 0.015611184680807176,
      'DIXON.NS': 0.006700133878447777,
      'ELGIEQUIP.NS': -0.0198616436120039,
      'FSL.NS': -0.03047492422806231,
      'GRANULES.NS': 0.024402361702895836,
      'HIMATSEIDE.NS': 0.022831260627788952,
      'IDFC.NS': -0.017559870324276704,
      'L&TFH.NS': 0.012380849079859904,
      'MANAPPURAM.NS': -0.028336428985308762,
      'NBCC.NS': 0.030382192026291686,
      'OBEROIRLTY.NS': 0.03250501823067955,
      'RAYMOND.NS': -0.006445062103522914,
      'SUNTECK.NS': -0.018613122489843828,
      'TV18BRDCST.NS': -0.03157819156655133,
      'UNIONBANK.NS': 0.03356004814823394,
      'VBL.NS': -0.026309810247538538,
      'YESBANK.NS': -0.008772242199757373,
      'ZEEL.NS': -0.025624510806987983,
      'AJANTPHARM.NS': -0.031146140861546084,
      'BLUESTARCO.NS': -0.027044063996905076,
      'CENTURYPLY.NS': 0.026925878716406493,
      'DALMIASUG.NS': -0.01233477160383503,
      'EMAMILTD.NS': -0.019971629959800216,
      'FINCABLES.NS': -0.007511134526524704,
      'GMDCLTD.NS': 0.004773483916759946,
      'HCC.NS': 0.028809974551473754,
      'ITDCEM.NS': -0.009606027556275567,
      'JSL.NS': 0.02428320070741932,
      'KSCL.NS': -0.03525646354011953,
      'LUXIND.NS': 0.009790870219451164})




```python

```


```python
model2= QuadraticOptimisation(returns=monthly_returns, risk_free_rate=0.05,allow_shortselling=False)
```


```python
model2.generate_efficient_frontier()
```


```python
model2.plot_efficient_frontier()
```


    
![png](output_19_0.png)
    



```python
model2.best_weights.sum()
```




    1.0000000000000926




```python
model2.get_min_variance_portfolio()
```

    Global Minimum Variance Portfolio:
    Expected Return: 0.0200
    Risk (Volatility): 0.4008
    Weights:
    RELIANCE.NS: 0.0000
    TCS.NS: 0.0215
    HDFCBANK.NS: 0.0592
    INFY.NS: 0.0816
    HINDUNILVR.NS: 0.0602
    ICICIBANK.NS: 0.0000
    BHARTIARTL.NS: 0.1471
    ITC.NS: 0.1373
    KOTAKBANK.NS: 0.0000
    LT.NS: 0.0000
    GODREJCP.NS: 0.0000
    FEDERALBNK.NS: 0.0679
    TATAPOWER.NS: 0.0000
    APOLLOHOSP.NS: 0.0000
    ASHOKLEY.NS: 0.0293
    MUTHOOTFIN.NS: 0.0000
    JUBLFOOD.NS: 0.0000
    BIOCON.NS: 0.0000
    CROMPTON.NS: 0.0000
    VMART.NS: 0.0000
    KEC.NS: 0.1139
    BAJAJELEC.NS: 0.0084
    CHALET.NS: 0.0000
    DIXON.NS: 0.0000
    ELGIEQUIP.NS: 0.0642
    FSL.NS: 0.0000
    GRANULES.NS: 0.0000
    HIMATSEIDE.NS: 0.0000
    IDFC.NS: 0.0000
    L&TFH.NS: 0.0000
    MANAPPURAM.NS: 0.0000
    NBCC.NS: 0.0000
    OBEROIRLTY.NS: 0.0000
    RAYMOND.NS: 0.0036
    SUNTECK.NS: 0.0000
    TV18BRDCST.NS: 0.0000
    UNIONBANK.NS: 0.0000
    VBL.NS: 0.0324
    YESBANK.NS: 0.0000
    ZEEL.NS: 0.0000
    AJANTPHARM.NS: 0.0000
    BLUESTARCO.NS: 0.0520
    CENTURYPLY.NS: 0.0000
    DALMIASUG.NS: 0.0000
    EMAMILTD.NS: 0.0571
    FINCABLES.NS: 0.0000
    GMDCLTD.NS: 0.0000
    HCC.NS: 0.0000
    ITDCEM.NS: 0.0000
    JSL.NS: 0.0000
    KSCL.NS: 0.0644
    LUXIND.NS: 0.0000
    
    




    (0.01080682146840614,
     0.4007827476453864,
     {'RELIANCE.NS': 1.2480523694471964e-07,
      'TCS.NS': 0.02145156880270777,
      'HDFCBANK.NS': 0.059159578250574704,
      'INFY.NS': 0.08160984844495527,
      'HINDUNILVR.NS': 0.060225071061224246,
      'ICICIBANK.NS': 3.697410543130692e-08,
      'BHARTIARTL.NS': 0.1470547819551925,
      'ITC.NS': 0.1372552362345267,
      'KOTAKBANK.NS': 9.291238898383356e-08,
      'LT.NS': 3.047304944585873e-08,
      'GODREJCP.NS': 4.710054098474556e-08,
      'FEDERALBNK.NS': 0.06791896542748162,
      'TATAPOWER.NS': 1.5184178117017796e-08,
      'APOLLOHOSP.NS': 1.985990195299842e-07,
      'ASHOKLEY.NS': 0.029290932905436162,
      'MUTHOOTFIN.NS': 2.7505506176402532e-08,
      'JUBLFOOD.NS': 3.827306939963547e-08,
      'BIOCON.NS': 3.731555470799761e-08,
      'CROMPTON.NS': 7.233099456285165e-08,
      'VMART.NS': 2.0568847453362597e-08,
      'KEC.NS': 0.11391313249634251,
      'BAJAJELEC.NS': 0.00842798557687874,
      'CHALET.NS': 5.1223465335057125e-08,
      'DIXON.NS': 3.985545414757706e-08,
      'ELGIEQUIP.NS': 0.06415643145878924,
      'FSL.NS': 1.3669324398242735e-08,
      'GRANULES.NS': 1.3163661992982232e-07,
      'HIMATSEIDE.NS': 1.3451617626601923e-08,
      'IDFC.NS': 1.8412149030341512e-08,
      'L&TFH.NS': 1.1900925273888153e-08,
      'MANAPPURAM.NS': 1.9587300716405205e-08,
      'NBCC.NS': 8.73375171353168e-09,
      'OBEROIRLTY.NS': 1.1196850455659774e-08,
      'RAYMOND.NS': 0.0036052259189620324,
      'SUNTECK.NS': 3.925918122873715e-08,
      'TV18BRDCST.NS': 6.923274250010223e-08,
      'UNIONBANK.NS': 1.6449054239189767e-08,
      'VBL.NS': 0.0324256168303126,
      'YESBANK.NS': 1.4372812974939548e-08,
      'ZEEL.NS': 1.2188628983359614e-08,
      'AJANTPHARM.NS': 5.560895883168678e-08,
      'BLUESTARCO.NS': 0.05199793694309457,
      'CENTURYPLY.NS': 3.7727013899972426e-08,
      'DALMIASUG.NS': 4.115071236429864e-08,
      'EMAMILTD.NS': 0.05707204827966842,
      'FINCABLES.NS': 1.554934940890607e-08,
      'GMDCLTD.NS': 3.322800201081612e-08,
      'HCC.NS': 1.535547959255167e-08,
      'ITDCEM.NS': 8.153625941898792e-09,
      'JSL.NS': 3.2563777938957866e-07,
      'KSCL.NS': 0.06443387937802536,
      'LUXIND.NS': 1.4412603534819057e-08})




```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
